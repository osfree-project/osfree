/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#if defined(WIN32)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "SDL_error.h"

#include "SDL_mmap.h"

#ifndef INVALID_SET_FILE_POINTER
#define INVALID_SET_FILE_POINTER ((DWORD)-1)
#endif

#define alloc_mspan() ((SDL_mspan *)malloc(sizeof(SDL_mspan)))

#define free_mspan(x) free(x)

static void win32_seterror()
{
  char *lpMsgBuf;
  FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        GetLastError(),
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

  SDL_SetError("Windows error: %s",lpMsgBuf);
  LocalFree(lpMsgBuf);
}


struct SDL_mmap
{
  HANDLE file;
  HANDLE fmap;
  Uint32 prot;
};

/* Returns the system page size */
Uint32 SDL_mmap_pagesize()
{
  SYSTEM_INFO si;
  GetSystemInfo(&si);
  return(si.dwPageSize);
}

/* Opens a file for memory mapping */
struct SDL_mmap *SDL_mmap_open(const char *fname, Uint16 prot,
  SDL_madvise_e optim)
{
  struct SDL_mmap *map=NULL;
  int flags,crflags,mflags,fattr=FILE_ATTRIBUTE_NORMAL;

//  if(raccess != SDL_FALSE) fattr|=FILE_FLAG_RANDOM_ACCESS;
//  else fattr|=FILE_FLAG_SEQUENTIAL_SCAN;
  switch(optim)
  {
  case SDL_MADVISE_NONE:
    break;

  case SDL_MADVISE_SEQUENTIAL:
    fattr|=FILE_FLAG_SEQUENTIAL_SCAN;
	break;

  case SDL_MADVISE_RANDOM:
    fattr|=FILE_FLAG_RANDOM_ACCESS;
	break;

  default:
    SDL_SetError("Unknown access optimization flag %d",optim);
	return(NULL);
  }

  switch(prot&(SDL_MMAP_RD|SDL_MMAP_WR))
  {
  case SDL_MMAP_RD|SDL_MMAP_WR:
	  crflags=OPEN_ALWAYS;
	  flags=GENERIC_READ|GENERIC_WRITE;
	  mflags=PAGE_READWRITE;
	  break;

  case SDL_MMAP_RD:
	  crflags=OPEN_EXISTING;
	  flags=GENERIC_READ;
	  mflags=PAGE_READONLY;
	  break;

  case SDL_MMAP_WR:
	  SDL_SetError("Win32 does not allow write-only pages");
	  return(NULL);

  default:
	  SDL_SetError("Cannot open without read or write flags");
	  return(NULL);
  }

  map=(struct SDL_mmap *)malloc(sizeof(struct SDL_mmap));
  if(map==NULL) return(NULL);

  map->file=INVALID_HANDLE_VALUE;
  map->fmap=INVALID_HANDLE_VALUE;
  map->prot=mflags;

  map->file=CreateFile(fname,flags,FILE_SHARE_READ|FILE_SHARE_WRITE,
		NULL,crflags,fattr,NULL);
  if(map->file==INVALID_HANDLE_VALUE)
    goto MAP_OPEN_ERR;

  return(map); // Return success

MAP_OPEN_ERR:
  win32_seterror();
  SDL_mmap_close(map);
  return(NULL);
}

int SDL_mmap_truncate(struct SDL_mmap *map, mmap_t size)
{
  Uint32 lw=LO_DWORD(size);
  Uint32 hw=HI_DWORD(size);

  if(map==NULL)
  {
    SDL_SetError("NULL mmap");
    return(1);
  }

  if(map->fmap != INVALID_HANDLE_VALUE)
  {
    CloseHandle(map->fmap);
	map->fmap=NULL;
  }

  if(SetFilePointer(map->file,lw,&hw,FILE_BEGIN)==INVALID_SET_FILE_POINTER)
  {
    win32_seterror();
    return(-1);
  }

  SetEndOfFile(map->file);
  return(0);
}

/* Closes a memory-mapped file.  Please unmap mem first. */
void SDL_mmap_close(struct SDL_mmap *map)
{
  if(map!=NULL)
  {
	if(map->fmap!=NULL)
		CloseHandle(map->fmap);
    if(map->file!=INVALID_HANDLE_VALUE)
		CloseHandle(map->file);
    free(map);
  }
}

/* Returns the length of the file in bytes */
int SDL_mmap_len(struct SDL_mmap *mm, mmap_t *size)
{
  Uint32 hiword;
  Uint32 loword=GetFileSize(mm->file,&hiword);
  if(loword==INVALID_FILE_SIZE)
  {
    win32_seterror();
    return(-1);
  }
  (*size)=loword|(((mmap_t)hiword)<<32);
  return(0);
}

/* Attempts to memory-map a segment of the file. */
SDL_mspan *      SDL_mmap(struct SDL_mmap *mm,
                          mempos_t length,
                          Uint16 prot,
                          mmap_t page)
{
  mmap_t offset;
  SDL_mspan *span;
  int flags=0;
  if(length == 0)
  {
    mmap_t llen;
    if(SDL_mmap_len(mm,&llen)<0)
	  return(NULL);

    llen-=(page*SDL_mmap_pagesize());
	if(llen > SDL_mmap_maxchunk())
	{
      SDL_SetError("File too large to fit in address space");
	  return(NULL);
	}
	length=(mempos_t)llen;
  }

  span=alloc_mspan();
  if(span==NULL) return(NULL);

  if(mm->fmap == INVALID_HANDLE_VALUE)
  {
    mm->fmap=CreateFileMapping(mm->file,NULL,mm->prot,0,0,NULL);
	if(mm->fmap == INVALID_HANDLE_VALUE)
	{
	  win32_seterror();
	  return(NULL);
	}
  }

  if(prot&SDL_MMAP_WR) flags|=FILE_MAP_WRITE;
  if(prot&SDL_MMAP_RD) flags|=FILE_MAP_READ;

  span->pagesize=SDL_mmap_pagesize();
  span->len=length;
  span->page=page;
  span->parent=mm;

  offset=(span->pagesize)*(mmap_t)page;

  span->mem=MapViewOfFile(mm->fmap,flags,HI_DWORD(offset),LO_DWORD(offset),0);
  if(span->mem==NULL)
  {
	win32_seterror();
	free_mspan(span);
    return(NULL);
  }

  return(span);
}

/* Unmaps a memory-mapped segment. */
int SDL_munmap(SDL_mspan *span)
{
  if(span==NULL)
  {
    SDL_SetError("NULL memory span");
    return(-1);
  }

  if(span->mem!=NULL)
  {
    SDL_mmap_flush(span,0,0);
    if(UnmapViewOfFile(span->mem)==0)
    {
      win32_seterror();
      return(-1);
    }
  }

  free_mspan(span);
  return(0);
}

int SDL_mmap_flush(SDL_mspan *span, mempos_t pageoff, mempos_t bytes)
{
  mempos_t offset=pageoff * span->pagesize;
  if(offset >= span->len)
  {
    SDL_SetError("Offset is beyond end of segment");
    return(-1);
  }

  if((span->len - offset) < bytes)
  {
    SDL_SetError("End goes beyond end of segment");
    return(-1);
  }

  if(FlushViewOfFile(span->mem + offset,(SIZE_T)bytes) == 0)
  {
    win32_seterror();
    return(-1);
  }

  return(0);
}

#endif/*defined(WIN32)*/
