/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#ifdef SDL_MMAP_UNIX

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#ifdef USE_MMAP2
#include <syscall.h>
#endif
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "SDL_mmap.h"

#ifdef __APPLE__
#define lseek64 lseek /* OSX has a 64-bit off_t */
#endif

#define alloc_mspan() ((SDL_mspan *)malloc(sizeof(SDL_mspan)))

#define free_mspan(x) free(x)


#ifdef USE_MMAP2
_syscall6(void *,mmap2, void *,start, size_t, length, int, prot,
          int, flags, int, ft, off_t, pgoffset)
#endif/*USE_MMAP2*/

static void SDL_perror(const char *msg)
{
  char buf[1024];
  strerror_r(errno,buf,1023);
  buf[1023]='\0';
  SDL_SetError("%s: %s",msg,buf);
}

struct SDL_mmap
{
  /* File descriptor */
  int fd;
  /* # of mapped memory segments left open */
  int mappings;
  /* Whether to advise the OS to optimize for random access */
  SDL_madvise_e optim;
};

struct SDL_mmap *SDL_mmap_open(const char *fname, Uint16 prot,
  SDL_madvise_e optim)
{
  struct SDL_mmap *mm=(struct SDL_mmap *)malloc(sizeof(struct SDL_mmap));
  int flag=0,acc=0;
  switch(prot&(SDL_MMAP_RD|SDL_MMAP_WR))
  {
  case SDL_MMAP_RD|SDL_MMAP_WR:
    flag=O_RDWR|O_CREAT;
    acc=0600;
    break;
  case SDL_MMAP_RD:
    flag=O_RDONLY;
    acc=0400;
    break;

  case SDL_MMAP_WR:
    flag=O_WRONLY;
    acc=0200;
    break;

  default:
    SDL_SetError("Memory you can't read or write is USELESS");
    return(NULL);
  }

  if(mm==NULL)
    return(NULL);

  switch(mm->optim)
  {
  case SDL_MADVISE_RANDOM:
  case SDL_MADVISE_SEQUENTIAL:
  case SDL_MADVISE_NONE:
    break;

  default:
    SDL_SetError("Unknown access optimzation flag %d\n",optim);
    return(NULL);
  }

  mm->optim=optim;
  mm->mappings=0;

  mm->fd=open(fname,flag,acc);
  if(mm->fd<0)
  {
    free(mm);
    return(NULL);
  }

  return(mm);
}

int SDL_mmap_truncate(struct SDL_mmap *mm,mmap_t len)
{
  if(mm->mappings)
  {
    SDL_SetError("Cannot truncate while mappings exist");
    return(-1);
  }

  if(ftruncate(mm->fd,len)<0)
  {
    SDL_perror("Couldn't truncate file");
    return(-1);
  }

//  if(mm->raccess != SDL_FALSE)
//    posix_fadvise(mm->fd.0,0,POSIX_FADV_RANDOM);

  return(0);
}

void SDL_mmap_close(struct SDL_mmap *mm)
{
  if(mm->fd<0) return;

  if(mm->mappings != 0)
    fprintf(stderr,"Warning!  Mappings still exist");

  close(mm->fd);
  free(mm);
}

int SDL_mmap_len(struct SDL_mmap *mm, mmap_t *len)
{
  mmap_t offset;
  if(mm == NULL)
  {
    SDL_SetError("NULL mmap");
    return(-1);
  }
  *len=lseek64(mm->fd,0,SEEK_END);
  return(0);
}


SDL_mspan *SDL_mmap(struct SDL_mmap *mm, mempos_t length, Uint16 prot,
  mmap_t page)
{
  int mmflag=0;
  SDL_mspan *s=alloc_mspan();

  if(s==NULL)
  {
    SDL_SetError("Couldn't alloc mspan");
    return(NULL);
  }

  s->pagesize=SDL_mmap_pagesize();

  if(length<0)
  {
    mmap_t llen;
    if(SDL_mmap_len(mm,&llen)<0)
      return(NULL);

    llen -= SDL_mmap_pagesize()*page;

    if(llen > SDL_mmap_maxchunk())
    {
      SDL_SetError("File too large to fit in address space");
      return(NULL);
    }

    length=(mempos_t)llen;
  }

  if(prot&SDL_MMAP_RD) mmflag|=PROT_READ;
  if(prot&SDL_MMAP_WR) mmflag|=PROT_WRITE;

//  fprintf(stderr,"mmap(%p,%d,0x%08x,0x%08x,%d,%d)\n",
//    NULL,length,mmflag,MAP_SHARED,fd,page);

#ifdef USE_MMAP2
  s->mem=mmap2(NULL,length,mmflag,MAP_SHARED,mm->fd,page);
#else
  s->mem=mmap(NULL,length,mmflag,MAP_SHARED,mm->fd,page*(s->pagesize));
#endif

  if(s->mem==MAP_FAILED)
  {
    SDL_perror("Couldn't map memory");
    free_mspan(s);
    return(NULL);
  }

  s->page=page;
  s->len=length;
  s->parent=mm;
  mm->mappings++;

  switch(mm->optim)
  {
  case SDL_MADVISE_RANDOM:
    if(madvise(s->mem,s->len,MADV_RANDOM)<0)
      fprintf(stderr,"Warning, couldn't optimize random access\n");
    break;
  case SDL_MADVISE_SEQUENTIAL:
    if(madvise(s->mem,s->len,MADV_SEQUENTIAL)<0)
      fprintf(stderr,"Warning, couldn't optimize sequential access\n");
    break;
  case SDL_MADVISE_NONE:
    break;
  }
//  if(mm->raccess)
//    if(madvise(s->mem,s->len,MADV_RANDOM)<0)
//      fprintf(stderr,"Warning, couldn't madvise random access\n");

  return(s);
}

int SDL_munmap(SDL_mspan *span)
{
  int retval;
  if(span==NULL)
  {
    SDL_SetError("NULL memory span");
    return(-1);
  }

  SDL_mmap_flush(span,0,0); // Flush all memory in span

  retval=munmap(span->mem,span->len);
  if(retval<0)
    SDL_perror("Couldn't unmap memory");

  span->parent->mappings--;

  free_mspan(span);
  return(retval);
}

int SDL_mmap_flush(SDL_mspan *span, mempos_t page, mempos_t bytes)
{
  mempos_t offset=page*span->pagesize;
  if(offset >= span->len)
  {
    SDL_SetError("SDL_mmap_flush:  page beyond end of segment");
    return(-1);
  }

  if(bytes==0)
    bytes=span->len - offset;

  if(msync(span->mem + offset, bytes,MS_SYNC)<0)
  {
    SDL_perror("Couldn't sync memory");
    return(-1);
  }

  return(0);
}

Uint32 SDL_mmap_pagesize()
{
  return(getpagesize());
}

#endif/*SDL_MMAP_UNIX*/
