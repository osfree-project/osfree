/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#include "SDL_types.h"
#include "SDL_mmap.h"

#define POINTER_BITS (sizeof(void *)*8)

static const SDL_version mmap_linked_version={
  SDL_MM_MAJOR,
  SDL_MM_MINOR,
  SDL_MM_PATCH };

mmap_t SDL_mmap_maxchunk()
{
  return(1L<<(POINTER_BITS-2));
}

const SDL_version *SDL_mmap_linked_version()
{
  return(&mmap_linked_version);  
}

int _SDL_mmap_ok(int major, int minor, int patch)
{
  if(major != mmap_linked_version.major)
  {
    fprintf(stderr,"Linked version of SDL_mmap has a different major version\n");
    return(0);
  }
  else if(minor < mmap_linked_version.minor)
  {
    fprintf(stderr,"Linked version of SDL_mmap has a smaller minor version\n");
    return(0);
  }
  else if(patch < mmap_linked_version.patch)
    fprintf(stderr,"Warning, compiled with %d.%d.%d but linked %d.%d.%d\n",
      major, minor, patch,
      mmap_linked_version.major,
      mmap_linked_version.minor, 
      mmap_linked_version.patch);

  return(1);
}

mmap_t SDL_mmap_pagealign(mmap_t value)
{
  Uint32 psize=SDL_mmap_pagesize();
  mmap_t extra=psize-(value%psize);
  if(extra<psize) value+=extra;
  return(value);
}

SDL_mspan *SDL_mmap_mapfile(const char *fname, Uint16 prot, SDL_madvise_e adv)
{
  mmap_t len;
  SDL_mspan *span=NULL;
  struct SDL_mmap *m=SDL_mmap_open(fname, prot, adv);
  if(m==NULL)
    goto SDL_MMAP_MAPFILE_ERR;

  if(SDL_mmap_len(m, &len)<0)
    goto SDL_MMAP_MAPFILE_ERR;

  if(len > SDL_mmap_maxchunk())
  {
    SDL_SetError("File length greater than maximum mappable size");
    goto SDL_MMAP_MAPFILE_ERR;
  }

  span=SDL_mmap(m, len, prot, 0);
  if(span == NULL)
    goto SDL_MMAP_MAPFILE_ERR;

  return(span);

SDL_MMAP_MAPFILE_ERR:
  if(span != NULL)
    SDL_munmap(span);
  if(m != NULL)
    SDL_mmap_close(m);
  return(NULL);
}

int SDL_mmap_freefile(SDL_mspan *m)
{
  struct SDL_mmap *mm;
  if(m == NULL)
    return(-1);

  mm=m->parent;
  SDL_munmap(m);
  SDL_mmap_close(mm);
  return(0);
}
