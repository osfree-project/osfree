SDL_mmap is a cross-platform memory mapping library.  Memory mapping is 
an elegant way of "loading" large amounts of data into memory without 
wasting said memory.  Via the magic of virtual memory, the file is 
literally mapped into memory.  See the Linux manpage for mmap to get a 
better idea.

Currently supported platforms are Linux, BSD, MacOS X, SunOS, Solaris, 
Windows 95 to XP, and Windows CE.

Changes from 0.1.0 to 1.0.0 include a "shortcut" API -- SDL_mmap_mapfile 
and SDL_mmap_freefile -- for converting a filename into a memory segment 
in a function call instead of the open-file/map-memory sequence required 
before.  The previous API is still there and remains compatible.

Written by Tyler Montbriand, 2007.  Licensed under the GNU LGPL.
