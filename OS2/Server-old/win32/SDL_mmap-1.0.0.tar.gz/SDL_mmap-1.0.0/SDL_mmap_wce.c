/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#if defined(_WIN32_WCE)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "SDL_error.h"

#include "SDL_mmap.h"

/*mmap_t SDL_mmap_maxchunk()
{
  return((~(Uint32)0)>>2);
}*/

#ifndef INVALID_SET_FILE_POINTER
#define INVALID_SET_FILE_POINTER ((DWORD)-1)
#endif

#define alloc_mspan() ((SDL_mspan *)malloc(sizeof(SDL_mspan)))

#define free_mspan(x) free(x)

static wchar_t *AscToUnicode(const char *str)
{
    wchar_t *w_str=NULL;
    if(str!=NULL)
    {
		int len=strlen(str)+1;
		w_str=(wchar_t *)malloc(sizeof(wchar_t)*len);
		if(MultiByteToWideChar(CP_ACP,0,str,-1,w_str,len)==0)
		{
	        free(w_str);
			return NULL;
	    }
	    else
	    {
	        return(w_str);
	    }
    }
    else
    {
	    return NULL;
    }
}

static char *UnicodeToAsc(const wchar_t *w_str)
{
    char *str=NULL;

    if(w_str!=NULL)
    {
    int len=wcslen(w_str)+1;
    str=(char *)malloc(len);

    if(WideCharToMultiByte(CP_ACP,0,w_str,-1,str,len,NULL,NULL)==0)
    {    //Conversion failed
        free(str);
        return NULL;
    }
    else
    {    //Conversion successful
        return(str);
    }

    }
    else
    {    //Given NULL string
    return NULL;
    }
}

static void wce_seterror()
{
  char *astr;
  wchar_t *lpMsgBuf;
  FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        GetLastError(),
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

  astr=UnicodeToAsc(lpMsgBuf);
  if(astr==NULL)
	  SDL_SetError("Windows error: Unknown");
  else
  {
      SDL_SetError("Windows error: %s",astr);
	  free(astr);
  }
  LocalFree(lpMsgBuf);
}

/**
 * This is uuuuugly.  We must store every detail
 * needed to re-open the file because of WCE's charming
 * habit of automatically closing the file handle when
 * the file mapping is closed.  These are very different
 * semantics from the W95/W98/ME and NT/2000/XP.
 */
struct SDL_mmap
{
  wchar_t *fname;
  Uint32 fmap_prot;    // read/write flags for fprot
  Uint32 file_rflags;  // Random access?
  Uint32 file_crflags; // file creation flags
  Uint32 file_acflags; // file access flags
  Uint32 mappings;     // # of open mappings

  HANDLE file;
  HANDLE fmap;
};

/* Returns the system page size */
Uint32 SDL_mmap_pagesize()
{
  SYSTEM_INFO si;
  GetSystemInfo(&si);
  return(si.dwPageSize);
}

static int wce_mmap_remap(struct SDL_mmap *mm)
{
  if(mm->fmap == INVALID_HANDLE_VALUE)
  {
    mm->fmap=CreateFileMapping(mm->file,NULL,
      mm->fmap_prot,0,0,NULL);
    if(mm->fmap==INVALID_HANDLE_VALUE)
      return(-1);

    // We don't need to close this now that we've
    // created a file mapping, the kernel will.
    mm->file=INVALID_HANDLE_VALUE;
  }

  return(0);
}

static int wce_mmap_reopen(struct SDL_mmap *mm)
{
  if(mm->mappings != 0)
  {
    SDL_SetError("Cannot do file ops, mappings still exist");
	return(-1);
  }

  if(mm->fmap != INVALID_HANDLE_VALUE)
  {
    CloseHandle(mm->fmap);
    mm->fmap=INVALID_HANDLE_VALUE;
  }

  if(mm->file != INVALID_HANDLE_VALUE) return(0);

  mm->file=CreateFileForMapping(mm->fname,
	mm->file_acflags,FILE_SHARE_READ,NULL,
	mm->file_crflags,mm->file_rflags,NULL);
  if(mm->file == INVALID_HANDLE_VALUE)
  {
    wce_seterror();
    return(-1);
  }

  return(0);
}

/* Opens a file for memory mapping */
struct SDL_mmap *SDL_mmap_open(const char *fname, Uint16 prot,
  SDL_madvise_e optim)
{
  struct SDL_mmap *mm=NULL;

  mm=(struct SDL_mmap *)malloc(sizeof(struct SDL_mmap));
  if(mm==NULL) return(NULL);

  mm->file_rflags=FILE_ATTRIBUTE_NORMAL;
  switch(optim)
  {
  case SDL_MADVISE_RANDOM:
	  mm->file_rflags|=FILE_FLAG_RANDOM_ACCESS;
	  break;

  case SDL_MADVISE_SEQUENTIAL:
	  // Windows CE does not support sequential scan
	  //mm->file_rflags=FILE_FLAG_SEQUENTIAL_SCAN;
	  break;

  case SDL_MADVISE_NONE:
	  break;

  default:
	  free(mm);
	  SDL_SetError("Unknown access optimization flag %d\n",optim);
	  return(NULL);
  }

  switch(prot&(SDL_MMAP_RD|SDL_MMAP_WR))
  {
  case SDL_MMAP_RD|SDL_MMAP_WR:
	  mm->file_crflags=OPEN_ALWAYS;
	  mm->file_acflags=GENERIC_READ|GENERIC_WRITE;
	  mm->fmap_prot=PAGE_READWRITE;
	  break;

  case SDL_MMAP_RD:
	  mm->file_crflags=OPEN_EXISTING;
	  mm->file_acflags=GENERIC_READ;
	  mm->fmap_prot=PAGE_READONLY;
	  break;

  case SDL_MMAP_WR:
	  SDL_SetError("Win32 does not allow write-only pages");
	  free(mm);
	  return(NULL);

  default:
	  SDL_SetError("Cannot open without read or write flags");
	  free(mm);
	  return(NULL);
  }

//  mm->file_rflags=FILE_ATTRIBUTE_NORMAL;

  mm->mappings=0;
  mm->file=INVALID_HANDLE_VALUE;
  mm->fmap=INVALID_HANDLE_VALUE;
  mm->fname=AscToUnicode(fname);
  if(mm->fname == NULL)
    goto MAP_OPEN_ERR;

  if(wce_mmap_reopen(mm)<0)
    goto MAP_OPEN_ERR;

  return(mm); // Return success

MAP_OPEN_ERR:
  wce_seterror();
  SDL_mmap_close(mm);
  return(NULL);
}

int SDL_mmap_truncate(struct SDL_mmap *mm, mmap_t size)
{
  Uint32 lw=LO_DWORD(size);
  Uint32 hw=HI_DWORD(size);

  if(mm==NULL)
  {
    SDL_SetError("NULL mmap");
    return(1);
  }

  if(mm->mappings != 0)
  {
    SDL_SetError("Cannot truncate, mappings still exist\n");
	return(-1);
  }

/*  if(mm->fmap!=INVALID_HANDLE_VALUE)
  {
    CloseHandle(mm->fmap);
	mm->fmap=INVALID_HANDLE_VALUE;
  }*/
  if(wce_mmap_reopen(mm)<0)
    return(-1);

  if(SetFilePointer(mm->file,lw,&hw,FILE_BEGIN)==INVALID_SET_FILE_POINTER)
  {
    wce_seterror();
    return(-1);
  }

  hw=0;
  SetEndOfFile(mm->file);
  SetFilePointer(mm->file,0,&hw,FILE_BEGIN);
  return(0);
}


/* Closes a memory-mapped file.  Please unmap mem first. */
void SDL_mmap_close(struct SDL_mmap *mm)
{
  if(mm!=NULL)
  {
	if(mm->fmap!=NULL)
		CloseHandle(mm->fmap);
    if(mm->file!=INVALID_HANDLE_VALUE)
		CloseHandle(mm->file);
	if(mm->fname != NULL)
		free(mm->fname);
    free(mm);
  }
}

/* Retrieves file size in bytes */
int SDL_mmap_len(struct SDL_mmap *mm, mmap_t *len)
{
  Uint32 hiword,loword;
  if(mm->mappings != 0)
  {
    SDL_SetError("Cannot do file ops, mappings still exist");
	return(-1);
  }

  loword=GetFileSize(mm->file,&hiword);
  if(loword==INVALID_FILE_SIZE)
  {
    wce_seterror();
	return(-1);
  }
  (*len)=loword|(((mmap_t)hiword)<<32);
  return(0);
}

/* Attempts to memory-map a segment of the file. */
SDL_mspan *      SDL_mmap(struct SDL_mmap *mm,
                          mempos_t length,
                          Uint16 prot,
                          mmap_t page)
{
  mmap_t offset;
  SDL_mspan *span;
  int flags=0;
  if(length < 0)
  {
    mmap_t llen;
    if(SDL_mmap_len(mm,&llen)<0)
      return(NULL);
	llen-=(page*SDL_mmap_pagesize());
	if(llen > SDL_mmap_maxchunk())
	{
	  SDL_SetError("File too large to fit in address space");
	  return(NULL);
	}

	length=(mempos_t)llen;
  }

  if(wce_mmap_remap(mm)<0)
    return(NULL);

  span=alloc_mspan();
  if(span==NULL) return(NULL);

  if(prot&SDL_MMAP_WR) flags|=FILE_MAP_WRITE;
  if(prot&SDL_MMAP_RD) flags|=FILE_MAP_READ;

  span->pagesize=SDL_mmap_pagesize();
  span->len=length;
  span->page=page;
  span->parent=mm;

  offset=(span->pagesize)*(mmap_t)page;

  span->mem=MapViewOfFile(mm->fmap,flags,HI_DWORD(offset),LO_DWORD(offset),0);
  if(span->mem==NULL)
  {
	wce_seterror();    
	free_mspan(span);
    return(NULL);
  }

  mm->mappings++;

  return(span);
}

/* Unmaps a memory-mapped segment. */
int SDL_munmap(SDL_mspan *span)
{
  if(span==NULL)
  {
    SDL_SetError("NULL memory span");
    return(-1);
  }

  if(span->mem!=NULL)
    if(UnmapViewOfFile(span->mem)==0)
      return(-1);

  span->parent->mappings--;
  span->parent=NULL;

  free_mspan(span);
  return(0);
}

int SDL_mmap_flush(SDL_mspan *span, mempos_t pageoff, mempos_t bytes)
{
  mempos_t offset=pageoff * span->pagesize;
  if(offset >= span->len)
  {
    SDL_SetError("Offset is beyond end of segment");
    return(-1);
  }

  if((span->len - offset) < bytes)
  {
    SDL_SetError("End goes beyond end of segment");
    return(-1);
  }

  if(FlushViewOfFile(span->mem + offset,(DWORD)bytes) == 0)
  {
    wce_seterror();
    return(-1);
  }

  return(0);
}

#endif/*defined(_WIN32_WCE)*/
