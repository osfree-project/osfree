/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#include "SDL.h"
#include "SDL_mmap.h"

#define TEST_OUT_STR "*MMAP"
#define TEST_OUT_FILE "testnew.txt"

void fill_mem(Uint8 *mem, const char *str, mmap_t len);

int main(int argc, char *argv[])
{
  mmap_t len;
  struct SDL_mmap *mm;
  const SDL_version *v;
  const char *fname="test.txt";
  SDL_mspan *span;

  if(!SDL_MMAP_OK)
  {
    fprintf(stderr,"Insufficient version of SDL_mmap\n");
    return(2);
  }

  if(argc==2)
	  fname=argv[1];

  v=SDL_mmap_linked_version();

  fprintf(stderr,"SDL_mmap linked version: %04d\n",
    SDL_VERSIONNUM(v->major,v->minor,v->patch));
  fprintf(stderr,"SDL_mmap compiled version: %04d\n",SDL_MM_COMPILEDVERSION);

  fprintf(stderr,"Max chunk size: %lu Mbytes\n",SDL_mmap_maxchunk()>>20);

  mm=SDL_mmap_open(fname,SDL_MMAP_RD,SDL_MADVISE_SEQUENTIAL);
  if(mm==NULL)
  {
    fprintf(stderr,"Couldn't open \"%s\": %s\n",fname,SDL_GetError());
    return(1);
  }

  if(SDL_mmap_len(mm,&len)<0)
  {
    fprintf(stderr,"Couldn't get length: %s\n",SDL_GetError());
	SDL_mmap_close(mm);
	return(1);
  }

  fprintf(stderr,"File is %ld bytes long\n",(int)len);

  span=SDL_mmap(mm,(mempos_t)len,SDL_MMAP_RD,0);
  if(span==NULL)
  {
    fprintf(stderr,"Couldn't map memory: %s\n",SDL_GetError());
    fprintf(stderr,"map failed\n");
    SDL_mmap_close(mm);
    return(2);
  }

  fprintf(stderr,"Memory mapped to %p\n",span->mem);

  fprintf(stderr,">> Beginning of \"%s\"\n",fname);
  fwrite(span->mem,1,(mempos_t)len,stderr);
  fprintf(stderr,">> End of \"%s\"\n",fname);

  SDL_munmap(span);
  SDL_mmap_close(mm);

  mm=SDL_mmap_open("testnew.txt",SDL_MMAP_RD|SDL_MMAP_WR,SDL_MADVISE_RANDOM);
  if(mm==NULL)
  {
	fprintf(stderr,"Couldn't open \"%s\" for writing: %s\n",TEST_OUT_FILE,SDL_GetError());
	return(1);
  }

  fprintf(stderr,"Opened \"%s\"\n",TEST_OUT_FILE);

  if(SDL_mmap_truncate(mm,SDL_mmap_pagesize())<0)
  {
    fprintf(stderr,"Couldn't truncate to %d bytes: %s\n",SDL_mmap_pagesize(),SDL_GetError());
	return(1);
  }

  fprintf(stderr,"Truncated to %d bytes\n",SDL_mmap_pagesize());

  span=SDL_mmap(mm,SDL_mmap_pagesize(),SDL_MMAP_WR|SDL_MMAP_RD,0);
  if(span==NULL)
  {
    fprintf(stderr,"Couldn't map writable span: %s\n",SDL_GetError());
	SDL_mmap_close(mm);
	return(1);
  }

  fprintf(stderr,"Mapped into memory at %p\n",span->mem);
  fill_mem(span->mem,TEST_OUT_STR,SDL_mmap_pagesize());

  fprintf(stderr,"Beginning of page>>\n%s\n>>End of page\n",span->mem);

  SDL_munmap(span);

  if(SDL_mmap_truncate(mm,SDL_mmap_pagesize()/2)<0)
  {
    fprintf(stderr,"Couldn't truncate: %s\n",SDL_GetError());
  }
  else
    fprintf(stderr,"Truncated to %d bytes\n",SDL_mmap_pagesize()/2);

  fprintf(stderr,
	  "There should now be a %d-byte file \"%s\" filled with string \"%s\"\n",
	  SDL_mmap_pagesize()/2,TEST_OUT_FILE,TEST_OUT_STR);

  SDL_mmap_close(mm);

  return(0);
}

void fill_mem(Uint8 *mem, const char *str, mmap_t len)
{
  int strpos=0;
  mmap_t n;

  for(n=0; n<len; n++)
  {
    mem[n]=str[strpos++];
	if(str[strpos]=='\0') strpos=0;
  }
  mem[len-1]='\0';
}
