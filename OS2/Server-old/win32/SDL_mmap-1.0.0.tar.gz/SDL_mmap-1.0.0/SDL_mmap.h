/**
 * (C) Tyler Montbriand, 2005
 * tsm@accesscomm.ca http://burningsmell.org
 *
 * Licensed under the GNU LGPL
 * http://www.gnu.org/copyleft/lesser.txt
 */
#ifndef __SDL_MMAP_H__
#define __SDL_MMAP_H__

#include "SDL_version.h"
#include "SDL_types.h"

/* Version information */
#define SDL_MM_MAJOR	1
#define SDL_MM_MINOR	0
#define SDL_MM_PATCH	0

#define SDL_MM_VERSION(X)		\
{					\
	(X)->major=SDL_MM_MAJOR;	\
	(X)->minor=SDL_MM_MINOR;	\
	(X)->patch=SDL_MM_PATCH;	\
}

#define SDL_MM_LINKEDVERSION					\
	SDL_VERSIONNUM(SDL_mmap_linked_version()->major		\
			SDL_mmap_linked_version()->minor,	\
			SDL_mmap_linked_version()->patch)	\

#define SDL_MM_COMPILEDVERSION \
  SDL_VERSIONNUM(SDL_MM_MAJOR,SDL_MM_MINOR,SDL_MM_PATCH)

#define SDL_MMAP_OK _SDL_mmap_ok(SDL_MM_MAJOR, SDL_MM_MINOR, SDL_MM_PATCH)

#define SDL_MMAP_RD 0x0001
#define SDL_MMAP_WR 0x0002

/**
 * Two different integer types are used to describe file positions
 * and memory positions.  On 64-bit systems these become the same.
 */

/*! \brief 64-bit type for file positions */
typedef Uint64 mmap_t;
/*! \brief machine-address size type for memory positions */
typedef long mempos_t;

#define HI_DWORD(X) ((Uint32)((X)>>32))
#define LO_DWORD(X) ((Uint32)((X)&0xffffffff))

typedef enum SDL_madvise_e
{
  SDL_MADVISE_NONE=0,		// No particular optimization
  SDL_MADVISE_SEQUENTIAL=1, // Optimize for sequential access
  SDL_MADVISE_RANDOM=2      // Optimize for random access
} SDL_madvise_e;

typedef struct SDL_mspan
{
  Uint8 *mem;      /* Pointer to mapped memory, change only CONTENTS */
  Uint32 pagesize; /* Page size, read-only */
  mmap_t page;     /* page offset in file, read-only */
  mempos_t len;    /* size of mapped area in bytes, read-only */
  struct SDL_mmap *parent; /* Pointer to parent obj */
} SDL_mspan;

#include "begin_code.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Returns the linked-in version of the SDL_mmap library */
DECLSPEC const SDL_version * SDLCALL SDL_mmap_linked_version();

DECLSPEC int SDLCALL _SDL_mmap_ok(int major, int minor, int patch);

/* Returns the maximum allowable size of a memory mapped segment */
DECLSPEC mmap_t SDLCALL SDL_mmap_maxchunk();

/* Returns the system page size */
DECLSPEC Uint32           SDLCALL SDL_mmap_pagesize();

/* Opens a file for memory mapping */
DECLSPEC struct SDL_mmap *SDLCALL SDL_mmap_open(const char *fname, 
                                                Uint16 prot,
                                                SDL_madvise_e optim);

/* Closes a memory-mapped file.  Please unmap mem first. */
DECLSPEC void             SDLCALL SDL_mmap_close(struct SDL_mmap *mm);

/* Retrieves file size in bytes */
DECLSPEC int SDLCALL SDL_mmap_len(struct SDL_mmap *mm, mmap_t *len);

/**
 * Sets the length of the file to a specific # of bytes.
 * Do NOT call when memory segments are mapped.
 */
DECLSPEC int              SDLCALL SDL_mmap_truncate(struct SDL_mmap *mm,
                                                    mmap_t bytes);

/**
 * Attempts to memory-map a segment of an open file.
 * bytes is the length to map.  prot is any combionation of
 * SDL_MMAP_RD and SDL_MMAP_WR.  page is the number of pages
 * to seek into the file.
 */
DECLSPEC SDL_mspan *      SDLCALL SDL_mmap(struct SDL_mmap *mm,
                                           mempos_t bytes,
                                           Uint16 prot,
                                           mmap_t page);
/* Unmaps a memory-mapped segment. */
DECLSPEC int              SDLCALL SDL_munmap(SDL_mspan *span);

/* Flushes a portion of, or all of a segment of mapped memory */
DECLSPEC int              SDLCALL SDL_mmap_flush(SDL_mspan *span,
                                                 mempos_t pageoff, 
                                                 mempos_t bytes);

/* Maps a file all at once with given permissions. */
DECLSPEC SDL_mspan * SDLCALL SDL_mmap_mapfile(const char *fname,
						Uint16 prot,
						SDL_madvise_e adv);

/* Frees a span loaded with SDL_mmap_mapfile. */
DECLSPEC int SDLCALL SDL_mmap_freefile(SDL_mspan *m);
#ifdef __cplusplus
}
#endif
#include "close_code.h"

#endif/*__SDL_MMAP_H__*/
