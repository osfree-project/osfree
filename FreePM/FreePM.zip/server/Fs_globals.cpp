/* 
 $Id: $ 
*/
/* Fs_globals.cpp */
/* server-side globals  */
/* ver 0.00 04.09.2002  */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "F_def.hpp"
#include "F_config.hpp"

#include "F_globals.hpp"
/*+---------------------------------+*/
/*| Global variables                |*/
/*+---------------------------------+*/
int _FreePM_id_index   = 0;
int _FreePM_NeedToExit = 0;
int _FreePM_detachedMode = 0;
/* defined in main():
   const char *const _FreePM_Application_Name;
   const char *const _FreePM_Application_Vers;
*/

/* debug support */
int _FreePM_db_level    = 7;
int _FreePM_debugLevels[MAX_DEBUG_SECTIONS];
int _FreePM_opt_debug_stderr = 5;
FILE *_FreePM_debug_log=NULL;

const char *const w_space = " \t\n\r";
const int  *const  w_t1 = (const int*)11;

int _FreePM_shutting_down = 0;
int _FreePM_FatalInProgress = 0;

/* time variables */
time_t  _FreePM_curtime = 0;
struct timeval _FreePM_current_time;
struct timeval _FreePM_start;
double _FreePM_current_dtime = 0.;



struct FreePM_Config _FreePMconfig =
{
/* struct Log */
   {
     "freepm.log",    /*  char *log;         */
     10               /*   int rotateNumber; */
   },
   "ALL,9", /* char *debugOptions; */

/* struct onoff */
   { 1,       /*  buffered_logs  */
     1,       /*  UseANSI_stdout */
     1        /*  UseBeepAtFatalError */

   }

};



