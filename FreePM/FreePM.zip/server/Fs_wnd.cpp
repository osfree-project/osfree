/* 
 $Id: $ 
*/
/* Fs_wnd.cpp */
/* server window manager (?) */
/* ver 0.00 3.03.2002       */
/* DEBUG: section 2   server WND manager */

#include <malloc.h>
#include <memory.h>
#include <builtin.h>
#include "FreePM.hpp"
#define INCL_DOSPROCESS
   #include "F_OS2.hpp"

#include "Fs_WND.hpp"

/* for debug()*/
#include <stdio.h>
#include "F_globals.hpp"

int F_WND_List::Add(void)
{   int i,rc,is,ind;
    int ilps_raz = 0, ilps_rc;
    do
    {  ilps_rc =  __lxchg(&Access,LOCKED);
       if(ilps_rc)
       { if(++ilps_raz  < 3)  DosSleep(0);
          else            DosSleep(1);
       }
    } while(ilps_rc);
/* ���饬 ���ᯮ��㥬� �������� ���ᨢ� pWND */
    is = 0;
    for(i=0;i<n;i++)
    { if(!pWND[i].used)
      {  is= 1;
         ind = i;
      }
    }
    if(!is) /* �� ��諨 ���⮥ ���� */
    {  if(n+1 >= nAlloced)
       {  nAlloced += 256;
          if(pWND == NULL)
          {        pWND = (WND *) calloc(nAlloced, sizeof(WND));
           /*  pWND[0] is formal, not realy used */
                   memset((void *)&pWND[0],0,sizeof(WND));
                   n = 1;
          }
          else
                  pWND = (WND *) realloc((void *)pWND, nAlloced* sizeof(WND));
       }
       ind = n++;
    }
    __lxchg(&Access,UNLOCKED);
    memset((void *)&pWND[ind],0,sizeof(WND));
    pWND[ind].used = 1;
debug(2, 0) ("WND_List::Add %i, n=%i\n",ind,n);
    return ind;
}

int F_WND_List::Query(int iWND)
{ int rc = 0;
  if(iWND < 0 || iWND >= n) rc = -1;
  if(pWND[iWND].used)       rc = 1;
  return rc;
}

int F_WND_List::Del(int iWND)
{  int ilps_raz = 0, ilps_rc;

   if(iWND < 0 || iWND >= n)
                 return 1;
   if(!pWND[iWND].used)
                 return 2;
debug(2, 0) ("WND_List::Del %i\n",iWND);
    do
    {  ilps_rc =  __lxchg(&Access,LOCKED);
       if(ilps_rc)
       { if(++ilps_raz  < 3)  DosSleep(0);
          else            DosSleep(1);
       }
    } while(ilps_rc);
    pWND[iWND].used = 0;
    if(iWND == n -1)
    {   while(n>0 && (pWND[n].used))
                     n--;
    }
    __lxchg(&Access,UNLOCKED);
    return 0;
}



























