/* 
 $Id: $ 
*/
/* Fs_WND.hpp */
/* ver 0.00 4.09.2002       */

/* The Window Structure (WND) */
/* This structure represents a window. It is created by WinCreateWindow.
    The WND has two main functions:
         It acts as the link between the MQ and the thread's window procedure
         It establishes the WND hierarchy.
*/

struct WND
{  int used;
   int iNextSibling;   /* index of Next sibling WND */
   int iParent;        /* index of Parent WND       */
   int iFirstChild;    /* index of First Child WND  */
   int iOwner;         /* index of Owner WND        */
   int iUserId;        /* user specified id         */

   int pMQ;     /* ? The pointer to the MQ that will queue messages sent and posted to this window  */
   int hwnd;    /* The windows's HWND  */
   int is16bit; /* ? A Boolean, which if non-zero, indicates that the window procedure address is a 16-bit far pointer  */
   int pWproc;  /* The address of the window procedure  */
   int word;    /* Window word */
};

/* class F_WND_List control global WND List (array) */
class F_WND_List
{  int n;         /* Number of array elements in pWND;*/
   int nAlloced;     /* Number of allocated array elements in pWND;*/
   struct WND *pWND;
   volatile int Access; /* fast access semaphor, use when pWND is realloced  */
public:
   F_WND_List(void)
   {  n = nAlloced = 0;
      pWND = NULL;
      Access = UNLOCKED;
   }
   int Add(void);
   int Query(int iHWND);
   int Del(int iHWND);
};

