/* 
 $Id: $ 
*/
/* Fc_main.cpp */
/* FreePM client side main*/
/* DEBUG: section 1     main client */
/* ver 0.01 22.08.2002       */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FreePM.hpp"
#define INCL_DOSPROCESS
#define INCL_DOSNMPIPES
#define INCL_DOSSEMAPHORES
   #include "F_OS2.hpp"
#include "F_pipe.hpp"
#include "F_utils.hpp"

/*+---------------------------------+*/
/*| External function prototypes.   |*/
/*+---------------------------------+*/

/*+---------------------------------+*/
/*| Internal function prototypes.   |*/
/*+---------------------------------+*/
int InitServerConnection(char *remotemachineName);
int CloseServerConnection(void);

int _F_SendCmdToServer(int cmd, int data);
int _F_SendDataToServer(void *data, int len);
int _F_RecvDataFromServer(void *data, int *len, int maxlen);

/*+---------------------------------+*/
/*| Global variables                |*/
/*+---------------------------------+*/
#include "F_globals.hpp"

const char *const _FreePM_Application_Name = FREEPM_CLIENT_APPLICATION_NAME;
const char *const _FreePM_Application_Vers = FREEPM_VERSION;

/*+---------------------------------+*/
/*| Static  variables               |*/
/*+---------------------------------+*/
static int nxDefault=800, nyDefault=600,  bytesPerPixelDefault=4;
static char *ExternMachine = NULL;   /* Name of external machine for pipes like \\MACHINE\PIPE\SQDR   */
static char ExternMachineName[_MAX_FNAME]="";
/*+---------------------------------+*/
/*|     local constants.            |*/
/*+---------------------------------+*/
char PipeName[256];


//class FreePM_session session;
class NPipe *pF_pipe;
static volatile int AccessF_pipe = UNLOCKED;
#define LOCK_PIPE                               \
    {   int ilps_raz = 0, ilps_rc;              \
        do                                      \
        {  ilps_rc =  __lxchg(&AccessF_pipe,LOCKED);  \
           if(ilps_rc)                          \
           { if(++ilps_raz  < 3)  DosSleep(0);  \
             else            DosSleep(1);       \
           }                                    \
        } while(ilps_rc);          \
    }

#define UNLOCK_PIPE  {__lxchg(&AccessF_pipe,UNLOCKED);}

int InitServerConnection(char *remotemachineName)
{  int rc;

static  char buf[256];

/* init time */
    getCurrentTime();

    _FreePM_start = _FreePM_current_time;

/* init debug */
    _db_init(_FreePMconfig.Log.log, _FreePMconfig.debugOptions);

   rc = QueryProcessType();
   if(rc == 4)
       _FreePM_detachedMode = 1;

   if(_FreePM_detachedMode)
   { debug(1, 0) ("Starting in detached mode %s version %s...\n",_FreePM_Application_Name, _FreePM_Application_Vers);
   } else {
     debug(1, 0) ("Starting %s version %s...\n",_FreePM_Application_Name, _FreePM_Application_Vers);
   }
   if(remotemachineName)
   {  strcpy(ExternMachineName,remotemachineName);
   } else {
       ExternMachineName[0] = 0;
/* test for FreePM's semaphore  at local machine */
       HMTX    FREEPM_hmtx     = NULLHANDLE; /* Mutex semaphore handle */
       rc = DosOpenMutexSem(FREEPM_MUTEX_NAME,    /* Semaphore name */
                            &FREEPM_hmtx);        /* Handle returned */
       DosCloseMutexSem(FREEPM_hmtx);
       if(rc)
       {   debug(1, 0)("%s is not running at local machine, exitting...\n",FREEPM_SERVER_APPLICATION_NAME);
           fatal("FreePM server not running");
       }
   }
/* init connection to FreePM server */
   if(ExternMachine)
   {
      sprintf(buf,"\\\\%s\\%s",ExternMachine,FREEPM_BASE_PIPE_NAME);
   } else {
      strcpy(buf,FREEPM_BASE_PIPE_NAME);
   }
   strcpy(PipeName,buf);

   pF_pipe = new NPipe(PipeName,CLIENT_MODE);

   rc = pF_pipe->Open();
   if(rc)
   {
      debug(1, 0)("F_pipe.Open rc = %i (%s)\n",rc,GetOS2ErrorMessage(rc));
      fatal("Can't open pipe");
   }
    rc = pF_pipe->HandShake();
    if(rc ==  HAND_SHAKE_ERROR)
    {   debug(1, 0)("Error handshake %i, pipe %s\n",rc,PipeName);
        fatal("Error handshake  pipe");
    }
//todo
    rc = 0;
    return rc;
}

int CloseServerConnection(void)
{   if(pF_pipe) { delete pF_pipe; pF_pipe = NULL;}

    return 0;
}

int _F_SendCmdToServer(int ncmd, int data)
{   int rc;
    LOCK_PIPE;

    rc = pF_pipe->SendCmdToServer( ncmd,  data);

     debug(1, 0) ("Send cmd %x %x, rc=%i\n",ncmd, data, rc);

    UNLOCK_PIPE;
   return rc;
}


int _F_SendDataToServer(void *data, int len)
{   int rc;
    LOCK_PIPE;

    rc = pF_pipe->SendDataToServer(data,  len);
     debug(1, 0) ("Send data %i bytes, rc=%i\n", len, rc);

    UNLOCK_PIPE;
   return rc;
}

int _F_RecvDataFromServer(void *data, int *len, int maxlen)
{   int rc;
    LOCK_PIPE;

    rc = pF_pipe->RecvDataFromClient(data, len, maxlen);
     debug(1, 0) ("Recv data %i bytes, rc=%i\n", *len, rc);

    UNLOCK_PIPE;
   return rc;
}

