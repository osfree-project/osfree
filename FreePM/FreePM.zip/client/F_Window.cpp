/* 
 $Id: $ 
*/
/* F_Window.cpp */
/* functions of class FreePM_Window */
/* ver 0.01 3.09.2002       */

#include "FreePM.hpp"
#include <malloc.h>

/* ᮧ����� ���� */
 FreePM_Window::FreePM_Window
                  (HWND hwndParent,  /*  Parent-window handle. */
                   PCSZ  _pszClass,   /*  Registered-class name. */
                   PCSZ  _pszName,    /*  Window text. */
                   ULONG _flStyle,    /*  Window style. */
                   LONG _x,          /*  x-coordinate of window position. */
                   LONG _y,          /*  y-coordinate of window position. */
                   LONG _nx,          /*  Width of window, in window coordinates. */
                   LONG _ny,          /*  Height of window, in window coordinates. */
                   HWND hwndOwner,   /*  Owner-window handle. */
                   HWND hwndInsertBehind, /*  Sibling-window handle. */
                   ULONG _rid,       /*  Window resource identifier. */
                   PVOID pCtlData,   /*  Pointer to control data. */
                   PVOID pPresParams)/*  Presentation parameters. */
{  int i;
   x = _x;
   y = _y;
   nx = _nx;
   ny - _ny;
   flStyle = _flStyle;
//   class_type = 0;
   pszClass = _pszClass;
   pszName  = _pszName;
   rid = _rid;

}

///* �������� ���� � ���⮯� */
//int FreePM_DeskTop::AddWindow(int x, int y, int nx, int ny, int bytesPerPixel)
//{
//
//   return 0;
//}
//
///* 㤠���� ���� � ���⮯� */
//int FreePM_DeskTop::DelWindow(int ind)
//{
//
//   return 0;
//}


int FreePM_Window::proc( HWND hwndWnd, ULONG ulMsg, MPARAM mpParm1,MPARAM mpParm2 )
{
 //todo
  return NULL;
}  


