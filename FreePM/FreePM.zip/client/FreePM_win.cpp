/* 
 $Id: $ 
*/
/* FreePM_win.cpp */
/* DEBUG: section 3 client Window manager */
/* ver 0.00 5.09.2002       */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FreePM.hpp"

#define INCL_DOSSEMAPHORES
#define INCL_DOSNMPIPES
#define INCL_DOSPROCESS
   #include "F_OS2.hpp"
#include "F_pipe.hpp"
#include "F_utils.hpp"
 #define INCL_WINERRORS /* Or use INCL_WIN, INCL_PM, */
 #define INCL_SHLERRORS
 #define INCL_GPIERRORS
#include "FreePM_win.hpp"
#include "F_hab.hpp"
#include "F_globals.hpp"
#include "FreePM_cmd.hpp"

static class _FreePM_HAB  _hab;

/*+---------------------------------+*/
/*| External function prototypes.   |*/
/*+---------------------------------+*/
int InitServerConnection(char *remotemachineName);
int CloseServerConnection(void);
int _F_SendCmdToServer(int cmd, int data);
int _F_SendDataToServer(void *data, int len);
int _F_RecvDataFromServer(void *data, int *len, int maxlen);

/*+---------------------------------+*/
/*| Internal function prototypes.   |*/
/*+---------------------------------+*/
MRESULT EXPENTRY _F_DefaultWindowProc( HWND hwndWnd, ULONG ulMsg, MPARAM mpParm1,MPARAM mpParm2 );

/*** WinInitialize/WinTerminate Interface declarations ******************/

/* WinInitialize
Input:
  flOptions (ULONG) - input  Initialization options.

     0       The initial state for newly created windows is that all messages for the window are available for
             processing by the application.
             This is the only option available in PM.
Output:
  hab (HAB) - returns   Anchor-block handle.

     NULLHANDLE         An error occurred.
     Other              Anchor-block handle.
Errors:
    PMERR_ALREADY_INITIALIZED
    FPMERR_INITSERVER_CONNECTION
*/

HAB APIENTRY WinInitialize(ULONG flOptions)
{   int ordinal,tid,rc, iHAB;
    ordinal = QueryThreadOrdinal(tid);
    rc = _hab.QueryOrdinalexist(ordinal);
    if(rc == -1)
    {  iHAB = _hab.AddHAB(ordinal);
    } else {
       _hab.SetError(rc, PMERR_ALREADY_INITIALIZED);
       return NULLHANDLE;

    }
/* Connect to server */
    rc =  InitServerConnection(NULL);
    if(rc)
    {  _hab.SetError(iHAB, FPMERR_INITSERVER_CONNECTION);
       return NULLHANDLE;
    }

    return iHAB;
}

BOOL APIENTRY WinTerminate(HAB ihab)
{   int rc;
    rc = CloseServerConnection();
    return TRUE;
}

HMQ     APIENTRY WinCreateMsgQueue(HAB ihab, LONG cmsg)
{   int ordinal,tid,rc, iHAB;
    rc = _hab.QueryHABexist(ihab);
    if(rc < 1)
    {  return NULLHANDLE;
    }
    _hab.hab[ihab].pQueue = new FreePM_Queue;
    return ihab; /* ihab = hmq */
}

BOOL    APIENTRY WinDestroyMsgQueue(HMQ hmq)
{   if(_hab.hab[hmq].pQueue)
    {
         delete _hab.hab[hmq].pQueue;
    }
    _hab.hab[hmq].pQueue = NULL;
    return TRUE;
}

BOOL    APIENTRY WinRegisterClass(HAB ihab,
                                  PCSZ  pszClassName,
                                  PFNWP pfnWndProc,
                                  ULONG flStyle,
                                  ULONG cbWindowData)
{
   return TRUE;
}

HWND  APIENTRY WinCreateStdWindow(HWND hwndParent,
                                  ULONG flStyle,
                                  PULONG pflCreateFlags,
                                  PSZ pszClientClass,
                                  PSZ pszTitle,
                                  ULONG styleClient,
                                  HMODULE hmod,
                                  ULONG idResources,
                                  PHWND phwndClient)
{
  HWND hwndFrame=NULL, hwndClient=NULL;
  int rc,data,len;

//create hwndClient
    rc = _F_SendCmdToServer(F_CMD_WINCREATE_HWND, 0);
//todo check rc
    rc = _F_RecvDataFromServer(&hwndFrame, &len, sizeof(HWND));
//todo check rc
//create hwndFrame
    rc = _F_SendCmdToServer(F_CMD_WINCREATE_HWND, 0);
//todo check rc
    rc = _F_RecvDataFromServer(&hwndClient, &len, sizeof(HWND));
//todo check rc
  *phwndClient = hwndClient;
//todo:
//make hwndFrame  frame window, hwndClient - client window
  return hwndFrame;
}

/*********************************************************************************
 WinGetMsg
 #define INCL_WINMESSAGEMGR  Or use INCL_WIN, INCL_PM, Also in COMMON section

 This function gets, waiting if necessary, a message from the thread's message queue
 and returns when a  message conforming to the filtering criteria is available.

 rc = WinGetMsg(hab, pqmsgmsg, hwndFilter, ulFirst, ulLast);

Return: rc (BOOL) - returns  Continue message indicator.

     TRUE   Message returned is not a WM_QUIT message
     FALSE  Message returned is a WM_QUIT message.

ERRORS:
  PMERR_INVALID_HWND (0x1001)     An invalid window handle was specified.
  FPMERR_NULL_POINTER             pqmsg is NULL
***********************************************************************************/
//todo: WM_QUIT catching
//todo: filter implementation
//todo: semaphore implementation with client-server
BOOL    APIENTRY WinGetMsg(HAB ihab,             /* Anchor-block handle.         */
                           PQMSG pqmsg,          /* Pointer to Message structure */
                           HWND hwndFilter,      /* Window filter          */
                           ULONG msgFilterFirst, /* First message identity */
                           ULONG msgFilterLast)  /* Last message identity  */
{   BOOL brc;
    int rc;

 debug(3, 2)("WinGetMsg call\n");

    if(pqmsg == NULL)
    {  _hab.SetError(ihab, FPMERR_NULL_POINTER);
       return TRUE;
    }
//test ihab
    rc =  _hab.QueryHABexist(ihab);
    if(rc != 1)
    {  //_hab.SetError(ihab - bad! , PMERR_INVALID_HAB);
       debug(3, 0)("WARNING: WinGetMsg: bad ihab %x\n",ihab);
       return TRUE;
    }
/***  Wait messages loop */
    do
    {
       rc = _hab.hab[ihab].pQueue->GetLength();
       if(rc)
       {  rc =  _hab.hab[ihab].pQueue->Get(pqmsg);
          if(rc == 0)
          {  debug(3, 1)("WinGetMsg Getmsg: hwnd %x, msg %x, mp1 %x, mp2 %x\n",pqmsg->hwnd,pqmsg->msg,pqmsg->mp1,pqmsg->mp2);
            return TRUE;
          }
       } else {
//todotodo
//Query messages from server
//         return TRUE;
       }
//No messages: Let's sleep
       DosSleep(1);
       debug(3, 4)("WinGetMsg Sleep\n");
    } while(1);

}

/*********************************************************************************
WinPeekMsg

Errors:
  PMERR_INVALID_HWND (0x1001)      An invalid window handle was specified.

  PMERR_INVALID_FLAG (0x1019)      An invalid bit was set for a parameter. Use constants defined
                                   by PM for options, and do not set any  reserved bits.

***********************************************************************************/

BOOL    APIENTRY WinPeekMsg(HAB ihab,
                            PQMSG pqmsg,
                            HWND hwndFilter,
                            ULONG msgFilterFirst,
                            ULONG msgFilterLast,
                            ULONG fl)
{   BOOL brc;
    int rc;
//test ihab
    rc =  _hab.QueryHABexist(ihab);
    if(rc != 1)
    {  //_hab.SetError(ihab - bad!, PMERR_INVALID_HAB);
       debug(3, 0)("WARNING: WinPeekMsg: bad ihab %x\n",ihab);
       return TRUE;
    }
//todo
    brc = TRUE;
    return brc;
}

/*

 The message contains hwnd, ulMsgid, mpParam1, mpParam2, and the time and pointer position when this
 function is called.

 WinPostMsg returns immediately, while WinSendMsg waits for the receiver to return.

 A thread which does not have a message queue can still call WinPostMsg but cannot call WinSendMsg.

FreePM extra: A thread wich even does not call WinInitialize can still call  WinPostMsg

Errors:
//PMERR_INVALID_HAB
PMERR_NO_MSG_QUEUE

*/
BOOL    APIENTRY WinPostMsg(HWND hwnd,
                               ULONG umsg,
                               MPARAM mp1,
                               MPARAM mp2)
{   int rc,i;
    QMSG msg;
    BOOL brc;
    msg.hwnd = hwnd;
    msg.msg = umsg;
    msg.mp1 = mp1;
    msg.mp2 = mp2;
    msg.time =  getCurrentTime(); /* � �।�������� time_t = int, todo */

//todo    msg.ptl =
    msg.uid = 0;
    msg.remoteId = 0;
    msg.dtime = _FreePM_curtime;

/* �஢�ਬ �� ����, �ਭ������騥  hab �� �।��� �ਭ��������� hwnd */
  rc = _hab.QueryHwnd(hwnd);
  if(rc > 0) /* ����७��� ᮮ�饭�� */
  {    int  iHABto;
       iHABto = rc -1;
       rc =  _hab.QueryHABexist(iHABto);
       if(rc != 1)
       {  _hab.SetError(PMERR_INVALID_HAB);
          debug(3, 0)("WARNING: WinPostMsg: bad iHABto %x for hwnd %x\n",iHABto,hwnd);

          return NULL;
       }

       if(_hab.hab[iHABto].pQueue == NULL)
       {  _hab.SetError(PMERR_NO_MSG_QUEUE);
          return NULL;
       }
       _hab.hab[iHABto].pQueue->Add(&msg);

  } else {      /* ���譥� ᮮ�饭�� */

     rc =  _F_SendCmdToServer(F_CMD_WINPOSTMSG, sizeof(QMSG));
     rc =  _F_SendDataToServer((void *)&msg, sizeof(QMSG));

  }

    brc = TRUE;
    return brc;
}

/**********************************************************

 mresReply is the value returned by the window procedure that is invoked. For standard window
 classes, the values of mresReply are documented with the message definitions.

 This function does not complete until the message has been processed by the window procedure
 whose  return value is returned in mresReply.

 If the window receiving the message belongs to the same thread, the window function is called
 immediately as a subroutine. If the window is of another thread or process, the operating
 system switches to the appropriate thread that enters the necessary window procedure recursively.
 The message is not  placed in the queue  of the destination thread.

 If a message is sent from one process to another and the message contains a pointer, the receiving
 process may not have read/write access to the memory referenced by the pointer. If the receiving
 process is expected to update that memory, this must be done using shared memory. For more
 information about Dynamic Data Exchange (DDE) and shared memory, see "Dynamic Data Exchange"
 section of the Presentation Manager Programming Guide - Advanced Topics.

************************************************************/
/*
Errors:
PMERR_INVALID_HAB
*/

MRESULT APIENTRY WinSendMsg(HWND hwnd,
                            ULONG umsg,
                            MPARAM mp1,
                            MPARAM mp2)
{   int rc,rcf,i,iHAB;
    QMSG msg;
    msg.hwnd = hwnd;
    msg.msg = umsg;
    msg.mp1 = mp1;
    msg.mp2 = mp2;
    msg.time =  getCurrentTime(); /* � �।�������� time_t = int, todo */

//todo    msg.ptl =
    msg.uid = 0;
    msg.remoteId = 0;
    msg.dtime = _FreePM_curtime;

/* �஢�ਬ �� ����, �ਭ������騥  hab �� �।��� �ਭ��������� hwnd */
  rc = _hab.QueryHwnd(hwnd);
  if(rc > 0) /* ����७��� ᮮ�饭�� */
  {    int ordinal, iHab, tid,iHABto, indpw;
       iHABto = rc -1;
       ordinal = QueryThreadOrdinal(tid);
       rc = _hab.QueryOrdinalexist(ordinal);
       if(rc == -1)
       {  _hab.SetError(PMERR_INVALID_HAB);
          debug(3, 0)("WARNING: WinSendMsg: error PMERR_INVALID_HAB\n");

         return NULL;
       }

       iHAB = rc;
       indpw = _hab.QueryHwnd(hwnd, iHABto);
       if(indpw == 0) /* May be if from QueryHwnd(hwnd) hwnd was deleted, todo: semafor or smth */
        {  _hab.SetError(iHAB, PMERR_INVALID_HWND);
          return NULL;
       }
       indpw--; /* indexes start from zero */
       if(iHAB == iHABto)
       {   if(_hab.hab[iHAB].pHwnd[indpw].pw == NULL)
           {    _hab.SetError(iHAB, FPMERR_NULL_WINDPROC);
                return NULL;
           }
           rcf = _hab.hab[iHAB].pHwnd[indpw].pw->proc(hwnd, umsg, mp1, mp2 );
       } else {
//todo: how to call proc from thread iHABto ?

//       _hab.hab[iHAB].pQueue->Add(&msg);
///* 横� �������� */
       }
  } else {      /* ���譥� ᮮ�饭�� */
     rc =  _F_SendCmdToServer(F_CMD_WINSENDMSG, sizeof(QMSG));
     rc =  _F_SendDataToServer((void *)&msg, sizeof(QMSG));
/* 横� �������� */
//todo

  }

    return NULL;
}


MRESULT APIENTRY WinDispatchMsg(HAB hab,
                                   PQMSG pqmsg)
{
//todo
  return NULL;
}


/*
WinGetLastError
WinGetLastError2
 This function returns the error code set by the failure of a Presentation Manager function.

 In multiple thread applications where there are multiple anchor blocks, errors are stored in the anchor
 block created by the WinInitialize function of the thread invoking a call. The last error for the process and
 thread on which this function call is made will be returned.

 Returns
 -1 = hab not exist or not used, or
  the last nonzero error code, and sets the error code to zero.
*/
ERRORID     APIENTRY    WinGetLastError(HAB iHAB)
{   int rc;
    rc = _hab.QueryHABexist(iHAB);
    if(rc != 1)
       return -1;
    rc = _hab.hab[iHAB].lastError;
    _hab.hab[iHAB].lastError = 0;
    return rc;

}

ERRORID     APIENTRY    WinGetLastError2(void)
{   int ordinal,tid,rc, iHAB;
    ordinal = QueryThreadOrdinal(tid);
    iHAB = _hab.QueryOrdinalexist(ordinal);
    if(iHAB == -1)
       return -1;

    rc = _hab.hab[iHAB].lastError;
    _hab.hab[iHAB].lastError = 0;
    return rc;
}


/*
 This function allocates a single private segment to contain the ERRINFO structure. All the pointers to string
 fields within the ERRINFO structure are offsets to memory within that segment.

 The memory allocated by this function is not released until the returned pointer is passed to the
 WinFreeErrorInfo function.

 Returns:

    NULL     No error information available
    Other    pointer to structure contains information about the previous error code for the current thread:

   { ERRINFO,       sizeof(ERRINFO)
     char *pstr,    sizeof(char *)
     NULL,          sizeof(char *)
     char str[]     strlen(errorinfo)+1
   }
*/
//todo: handle "thread not initialized to FreePM (PMERR_INVALID_HAB)"

PERRINFO    APIENTRY    WinGetErrorInfo(HAB iHAB)
{  int rc, errid,l;
   ERRINFO *perrInf;
   char *perrstr, *perrInfStr, * *ptr;

   errid = WinGetLastError(iHAB);
   if(errid == -1) return NULL;
   perrstr = GetFreePMErrorMessage(errid);
   l = strlen(perrstr);

   perrInf = (PERRINFO) calloc(sizeof(ERRINFO)+ l+1 + 2 * sizeof(char *)+1, 1);
   perrInf->cbFixedErrInfo = sizeof(ERRINFO);
   perrInf->idError =  errid;
   perrInf->offaoffszMsg = sizeof(ERRINFO);
   perrInf->offBinaryData = 0;
   ptr = (char * *)( ((char *)perrInf) + sizeof(ERRINFO));
   perrInfStr = ((char *)perrInf) + sizeof(ERRINFO) + 2 * sizeof(char *);
   strcpy(perrInfStr,perrstr);
   *ptr =  perrInfStr;
   return perrInf;
}

BOOL        APIENTRY    WinFreeErrorInfo(PERRINFO perrinfo)
{  if(perrinfo == NULL) return FALSE;
   free(perrinfo);
   return TRUE;
}


/***************************/


MRESULT EXPENTRY _F_DefaultWindowProc ( HWND hwndWnd, ULONG ulMsg, MPARAM mpParm1,MPARAM mpParm2 )
{
//todo
  return NULL;
}



