/* 
 $Id: $ 
*/
/* F_Client.cpp*/
#define POKA 0
#define DEBUG 0
/* ver 0.01 24.08.2002       */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "FreePM.hpp"

#define INCL_DOSSEMAPHORES
#define INCL_DOSNMPIPES
#define INCL_DOSPROCESS
   #include "F_OS2.hpp"
#include "F_pipe.hpp"

#include "FreePM_win.hpp"


/*+---------------------------------+*/
/*| Global variables                |*/
/*+---------------------------------+*/
#include "F_globals.hpp"


/* Internal functions prototypes */

int SendQueryToServer(char *qurl, char *bufout,int bufoutlen);
int QueryProcessType(void);
int QueryThreadOrdinal(int &tid);

int CloseThreadPipe(void);


struct LogFileStat *globalErrorLog = NULL;
struct LogFile *globalLogFile = NULL;

struct LogFileStat *lastLogFileStat;
struct LogFileStat *LogFileStat;


char **globalArgv ;
char **globalEnvp ;

int globalDebug = 0;
int globalPid = 0;
char *globalLogDir = NULL;

int sockSquid= -1;
static const char *hello_string = "hi there\n";
char *progname;
char *ExternMachine = NULL;

#define LOCKED    1
#define UNLOCKED  0

//class NPipe SQDRpipe;
class ProccessPipes ProcPipes;
volatile int ProccessPipes::Access=UNLOCKED;


int    detachedMode=0;

HMTX   SQDR_hmtx     = NULLHANDLE; /* Mutex semaphore handle */
void  _Optlink CloseAllClientConnection(void)
{   int i;
    for(i=0;i<32;i++)
    {  if(ProcPipes.pipe[i].used)
       {  if(ProcPipes.pipe[i].Hpipe)
           {  DosClose(ProcPipes.pipe[i].Hpipe);
              ProcPipes.pipe[i].Hpipe = NULL;
              ProcPipes.pipe[i].used = 0;
              ProcPipes.pipe[i].threadOrdinal = 0;
              ProcPipes.pipe[i].threadOrdinal = 0;
           }
       }
    }
}

int InitClientConnection(char *externMachineName)
{   int rc,ierr;
    ProcPipes.externMachineName = externMachineName;
    ProcPipes.ThreadPipeOpen(ierr);
    atexit(CloseAllClientConnection);
    return ierr;
}

int CloseThreadPipe(void)
{  int np;
   ProcPipes.CloseThread();
/*
   np = ProcPipes.QueryThreadPipeNum();
   if(np >= 0)
   {   if(ProcPipes.pipe[np].used && ProcPipes.pipe[np].Hpipe)
       {    DosClose(ProcPipes.pipe[np].Hpipe);
              ProcPipes.pipe[np].Hpipe = NULL;
              ProcPipes.pipe[np].used = 0;
              ProcPipes.pipe[np].threadOrdinal = 0;
        }
   }
*/
   return 0;
}

/*
   rc =
0 - Ok
1 - ERROR_INVALID_PARAMETER  - H������⨬� ��p����p
2 - Can't open pipe(s)
3 - Error handshake  pipe, Exitting

*/

int ThreadPipe::InitClientConnection(char *externMachineName)
{
  int ch,i,ii,rep;
  struct Source *src;
static  char lastquery[MAX_PIPE_BUF]="",bufout[MAX_PIPE_BUF];
  char str[256];
  char *redirect;
  time_t t;
      int fd=-1;
      int rc, t0,t01;

  if(externMachineName && externMachineName[0]) ExternMachine = externMachineName;


/*****************************************************/

    rc = DosOpenMutexSem(FREEPM_MUTEX_NAME,      /* Semaphore name */
                         &SQDR_hmtx);            /* Handle returned */

//printf("[%i] DosOpenMutexSem rc=%i  ",globalPid,rc); fflush(stdout);

    DosCloseMutexSem(SQDR_hmtx);

/* ����᪠�� �ࢥ� �� �����쭮� ��設� - �᫨ �� 㦥 ����饭 - ᠬ �뢠����� */
   if(rc && !ExternMachine)
   {
      if(detachedMode)
      {  sprintf(str,"detach %s",_FreePM_Application_Name);
         rc = system(str);
         debug(1, 0)("%s, rc=%i",str,rc);
         if(rc == -1)
         {  debug(1, 0)("errno =%i, _doserrno=%i",errno,_doserrno);
         }
      } else {
//         printf("[%i]start /N sqdrserver ",globalPid); fflush(stdout);
         sprintf(str,"start /N %s",_FreePM_Application_Name);
         rc = system(str);
         printf("%s rc=%i\n",str,rc); fflush(stdout);

         if(rc == -1)
         {
           debug(1, 0)("errno =%i, _doserrno=%i",errno,_doserrno);
         }
     }
     DosSleep(200);
   }
   for(rep=0,i=0;i<MAX_NUM_PIPES*2,rep<40+MAX_NUM_PIPES;i++)
   {  ii = i % MAX_NUM_PIPES;
      if(ExternMachine)
      {  if(i) sprintf(buf,"\\\\%s\\%s%i",ExternMachine,FREEPM_BASE_PIPE_NAME,ii);
         else sprintf(buf,"\\\\%s\\%s",ExternMachine,FREEPM_BASE_PIPE_NAME);
      } else {
         if(i) sprintf(buf,"%s%i",FREEPM_BASE_PIPE_NAME,ii);
         else strcpy(buf,FREEPM_BASE_PIPE_NAME);
      }
//      SQDRpipe = NPipe(buf,CLIENT_MODE);
      strcpy(name,buf);
      rc = Open();
      if(rc == ERROR_PIPE_BUSY)
               continue;
      if(rc == ERROR_PATH_NOT_FOUND)
      {  rep++;
         DosSleep(50+rep);
         continue;
      }
      if(rc)
      {  printf("Error open pipe rc=%i",rc);
         debug(1, 0)("Error open pipe rc=%i, Exitting",rc);
         if(rc == ERROR_INVALID_PARAMETER) printf("(H������⨬� ��p����p");
         return 1;
      }
      break;
    }
    if(!Hpipe)
    {  printf("Can't open pipe(s)");
       debug(1, 0)("Can't open pipe(s), Exitting");
       return 2;
    }
//    printf("Open pipe=%i\n",rc);
    rc = HandShake();
//    printf("HandShake=%i\n",rc);
    if(rc ==  HAND_SHAKE_ERROR)
    {
        printf("Error handshake\n",rc);
        debug(1, 0)("Error handshake  pipe, Exitting");
        DosBeep(1000,1000);
        DosBeep(2000,1000);
        return 3;
    }
    return 0;
}


/************************/
int SendQueryToServer(char *qurl, char *bufout,int bufoutlen)
{  int l,rc,ncmd,data,ierr;
  class  ThreadPipe *pPipe;
   if(!qurl)
      return -1;
   l = strlen(qurl);
   if(!l)
      return -2;
   pPipe = ProcPipes.ThreadPipeOpen(ierr);
   if(ierr)
      return ierr;
   l++; //+ zero at end of string
   rc = pPipe->SendCmdToServer(1,l); // ������� 1 - ��᫠�� ����� � �����
   if(rc)
      return rc;
   rc = pPipe->SendDataToServer((void *)qurl, l);
   if(rc)
      return rc;
   rc = pPipe->RecvCmdFromClient(&ncmd,&data);
   if(rc)
      return rc;
   switch(ncmd)
   {  case 1:
        l = data;
        rc = pPipe->RecvDataFromClient(bufout,&l,bufoutlen);
          break;

   }

   return rc;
}



#if POKA


/* ����� ����殮��� � ����㠫쭮�� ���稪� �஢�� �� �����஢�� */
/* �����頥� �⪫������ �஢�� � ��, ���������� � ����殮��� � 1�� � 2�� ᥭ�஢*/
int GetLevelV(struct VirtLevelData *pldata, int Numpoint)
{  struct VirtLevelData ldtmp , *pld;
   int rc,l,ierr;
   class  ThreadPipe *pPipe;
  pPipe = ProcPipes.ThreadPipeOpen(ierr);
  if(ierr)
      return ierr;
  pld = pldata;
   if(pld == NULL) pld = &ldtmp;
   rc = pPipe->SendCmdToServer(LSC_GET_LEVELV,Numpoint);
   rc = pPipe->RecvDataFromClient(pld,&l,sizeof(struct VirtLevelData ));
   return rc;
}

//�����稪 ⥬������� � �����
int SetCameraTargetTemp(float targetTemp)
{
   int rc,l,ierr, data;
   class  ThreadPipe *pPipe;
  pPipe = ProcPipes.ThreadPipeOpen(ierr);
  if(ierr)
      return ierr;
  data = * ((int *)&targetTemp);
   rc = pPipe->SendCmdToServer(LSC_SETCAMERATARGET_TEMP,data);
   return rc;
}
/* ����祭��-�몫�祭��  ����� */
int LaserTurnOnOff(int OnOff)
{  int rc,rc0=5,l,ierr;
   class  ThreadPipe *pPipe;
   pPipe = ProcPipes.ThreadPipeOpen(ierr);
   if(ierr)
      return ierr;
  rc = pPipe->SendCmdToServer(LSC_TURN_VIRTLASER,OnOff);
   rc = pPipe->RecvDataFromClient(&rc0,&l,sizeof(int));
   return rc0;
}


int QueryJobInfo(struct TaskInfo &taskinf)
{  int rc, l, data, ierr;
   class  ThreadPipe *pPipe;
   struct TaskInfo taskinfo;
   pPipe = ProcPipes.ThreadPipeOpen(ierr);
   data = 0;

   rc = pPipe->SendCmdToServer(LSC_QUERY_JOB_INFO,data);
   rc = pPipe->RecvDataFromClient(&taskinf,&l,sizeof(struct TaskInfo));
   if(!rc)
       taskinfo = taskinf;
   return rc;
}

int SetJobInfo(struct TaskInfo &taskinf)
{  int rc, l, data, ierr;
   class  ThreadPipe *pPipe;
   struct TaskInfo taskinfo;
   pPipe = ProcPipes.ThreadPipeOpen(ierr);
   data = 0;
   rc = pPipe->SendCmdToServer(LSC_SET_JOB_INFO,data);
   rc = pPipe->SendDataToServer(&taskinf,sizeof(struct TaskInfo));
   return rc;
}

#endif
