/* 
 $Id: $ 
*/
/* F_hab.cpp */
/* functions for HAB management */
/* ver 0.01 5.09.2002       */

#include <malloc.h>
#include "FreePM.hpp"
#include "F_hab.hpp"

/*+---------------------------------+*/
/*| External function prototypes.   |*/
/*+---------------------------------+*/
int QueryThreadOrdinal(int &tid);


/*
 HAB - "Handle Ancor Block"
 HAB handles thread-specific info:
- last PM error per thread
- whats else ?

*/
/* return:
-1 - not found,
else iHAB
*/
int _FreePM_HAB::QueryOrdinalexist(int ordinal)
{  int i,rc = -1;
    for(i = 0; i < n; i++)
    {  if(hab[i].used)
       {  if(hab[i].ordinal == ordinal)
          { return i;
          }
       }
    }
    return -1;
}


/*  return:
  -1 - bad iHAB
   0 - free
   1 - used
*/

int _FreePM_HAB::QueryHABexist(int iHAB)
{  int rc = 0;
   if(iHAB < 0 || iHAB >= n) rc = -1;
   else if(hab[iHAB].used)   rc = 1;
   return rc;
}

/* GetCurrentHAB
Return:
-2 - thread not initialized to FreePM (PMERR_INVALID_HAB)
 else iHAB
*/
int _FreePM_HAB::GetCurrentHAB(void)
{   int ordinal,tid,rc, iHAB;

    ordinal = QueryThreadOrdinal(tid);
    rc = QueryOrdinalexist(ordinal);
    if(rc != 1)
       return -2;
    return rc;
}
/*
  return:
-1 = no space for HAB info, increase  FREEPMS_MAX_NUM_THREADS
or iHAB
*/
int _FreePM_HAB::AddHAB(int ordinal)
{   int i,isfree=0;
    for(i = 0; i < n; i++)
    {  if(!hab[i].used)
       {  isfree = 1;
          break;
       }
    }
    if(!isfree)
    { if(n < FREEPMS_MAX_NUM_THREADS)
      { isfree = 1;
        i = n++;
      } else
          return -1;
    }
    hab[i].used = 1;
    hab[i].ordinal = ordinal;
    hab[i].Access  = UNLOCKED;
    hab[i].lastError = 0;
    hab[i].pQueue = NULL;
    hab[i].msgSendTo = 0;
    hab[i].nHwnd     = 0;
    hab[i].lAllocpHwnd = 0;
    hab[i].pHwnd  = NULL;

    return i;
}
/*  return:
 -1 - ordinal not found
  0 - Ok
*/
int _FreePM_HAB::DelHAB(int ordinal)
{  int i,is=0;
    for(i = 0; i < n; i++)
    {  if(hab[i].used)
       {  if(hab[i].ordinal == ordinal)
          { is = 1;
            break;
          }
       }
    }
    if(!is)
         return -1;
/* test for semaphor ?? hab[i].Access */
    hab[i].used = 0;
    hab[i].ordinal = 0;
    hab[i].Access  = UNLOCKED;
    if(hab[i].pQueue)
    {  delete hab[i].pQueue;
       hab[i].pQueue = NULL;
    }
    return 0;
}

/* returns:
 -1 - bad iHAB
 -2 - ordinal not used
  0 - Ok
*/
int _FreePM_HAB::SetError(int iHAB, int err)
{  int rc=0;
   if(iHAB < 0 || iHAB >= n) rc = -1;
   else if(!hab[iHAB].used)  rc = -2;
   else  hab[iHAB].lastError = err;
   return rc;
}

int _FreePM_HAB::SetError(int err)
{  int  rc=0, iHAB;
   iHAB = GetCurrentHAB();
   if(iHAB < 0 || iHAB >= n) rc = -1;
   else if(!hab[iHAB].used)  rc = -2;
   else  hab[iHAB].lastError = err;
   return rc;
}


/* returns:
 -1 - bad iHAB
 -2 - ordinal not used
else
 lastError
*/
int _FreePM_HAB::QueryError(int iHAB)
{  int rc;
   if(iHAB < 0 || iHAB >= n) rc = -1;
   else if(!hab[iHAB].used)  rc = -2;
   else rc = hab[iHAB].lastError;
   return rc;
}

/* �������� 奭�� ���� � ᯨ�� ���� ������᪮� ����� */
/* return:
    -1 - PMERR_INVALID_HWND
    -2 - thread not initialized to FreePM (PMERR_INVALID_HAB)
*/
int _FreePM_HAB::AddHwnd(HWND hwnd, FreePM_Window *pw)
{   int ordinal,tid,rc, iHAB;
    int i,n;
/* ᭠砫� �஢�ਬ, ��� �� 㦥 �⮣� ���� � ᯨ᪥ */
    rc = QueryHwnd(hwnd);
    if(rc > 0)
       return -1;
    ordinal = QueryThreadOrdinal(tid);
    rc = QueryOrdinalexist(ordinal);
    if(rc == -1)
       return -2;
    iHAB = rc;
    rc = AddHwnd(hwnd, iHAB, pw);

    return rc;
}

int _FreePM_HAB::AddHwnd(HWND hwnd, int iHAB, FreePM_Window *pw)
{   int i,rc,n;
/* ᭠砫� �஢�ਬ, ��� �� 㦥 �⮣� ���� � ᯨ᪥ */
    rc = QueryHwnd(hwnd);
    if(rc > 0)
       return -1;
    if(hab[iHAB].nHwnd+1 >= hab[iHAB].lAllocpHwnd)
    {   hab[iHAB].lAllocpHwnd += 256;
        if(hab[iHAB].pHwnd == NULL)
                       hab[iHAB].pHwnd = (_FreePM_hwnd *) calloc(hab[iHAB].lAllocpHwnd, sizeof(_FreePM_hwnd));
        else
                       hab[iHAB].pHwnd = (_FreePM_hwnd *) realloc((void *)hab[iHAB].pHwnd, hab[iHAB].lAllocpHwnd * sizeof(_FreePM_hwnd));
    }
    hab[iHAB].pHwnd[hab[iHAB].nHwnd].hwnd = hwnd;
    hab[iHAB].pHwnd[hab[iHAB].nHwnd].pw = pw;
    rc = hab[iHAB].nHwnd++;
    return rc;
}

/* Return:
   iHab+1 if hwnd is in HABs, else
   0
 */
int _FreePM_HAB::QueryHwnd(HWND hwnd)
{   int i,is,rc;
    is = 0;
    for(i=0;i<n;i++)
    {  rc = QueryHwnd(hwnd, i);
       if(rc > 0) return (i+1);
    }
   return 0;
}

/* Return:
   i+1 if hwnd is in HAB, else
   0
 */
int _FreePM_HAB::QueryHwnd(HWND hwnd, int iHAB)
{  int rc,i;
   rc = QueryHABexist(iHAB);
   if(rc != 1)
        return -1;
   if(hab[iHAB].pHwnd == NULL)
           return -2;
    for(i=0;i < hab[iHAB].nHwnd;i++)
    { if(hab[iHAB].pHwnd[i].hwnd == hwnd)
                   return i+1;
    }
    return 0;
}

/*  㤠���� ���� �� ᯨ᪠ ���� ������᪮� ����� */
/* Return:
   -1 - PMERR_INVALID_HWND
   -2 - thread not initialized to FreePM (PMERR_INVALID_HAB)
    0 - Ok
 */
int _FreePM_HAB::DelHwnd(HWND hwnd)
{   int i,rc;
    int ordinal,tid,iHAB;
    rc = QueryHwnd(hwnd);
    if(rc <= 0)
       return -1;

    ordinal = QueryThreadOrdinal(tid);
    rc = QueryOrdinalexist(ordinal);
    if(rc == -1)
       return -2;
    iHAB = rc;
    rc = DelHwnd(hwnd, iHAB);

    return rc;
}

int _FreePM_HAB::DelHwnd(HWND hwnd, int iHAB)
{   int i,rc;
    rc = QueryHwnd(hwnd,iHAB);
    if(rc <= 0)
       return -1;

    for(i=rc;i<hab[iHAB].nHwnd-1;i++)
    {   hab[iHAB].pHwnd[i] = hab[iHAB].pHwnd[i+1];
    }
    hab[iHAB].nHwnd--;
    return 0;
}

