/* 
 $Id: $ 
*/
/* F_utils.hpp */
/* ver 0.00 22.08.2002 */

#ifndef FREEPM_UTILS
 #define FREEPM_UTILS

#include <sys/time.h>


time_t getCurrentTime(void);

int OS2SetRelMaxFH(int ReqCount);

#endif
   /* FREEPM_UTILS */
