#!/bin/sh
zip -R Regression *.ASM *.EXP *.INC *.LIB *.BAT *.CMD *.txt *.sh
